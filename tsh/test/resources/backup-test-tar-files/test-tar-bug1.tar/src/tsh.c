#include "inc/shell.h"

static void init_starting_state();
static int run(s_command *s_command);
static void print_prompt(char *path);
static void exec_external_command(const s_command *cmd);

static s_tsh_state g_state;

int main(int argc, char *argv[]) {
	char command_line[CMD_MAX_SIZE];
	s_command *commands_ll;
	int shell_status = OK;

	init_starting_state();

	write(STDOUT_FILENO, WELCOME_MSG, WELCOME_MSG_LENGTH);

	while (EXIT != shell_status) {
		print_prompt(commons_tsh_get_path_from(g_state.cwd));

		memset(command_line, NONECHAR, CMD_MAX_SIZE);
		read(STDIN_FILENO, command_line, CMD_MAX_SIZE);

		commands_ll = parse(strndup(command_line, strlen(command_line)-1),
							commons_tsh_get_path_from(g_state.cwd));

		if (NULL == commands_ll) {
			write(STDOUT_FILENO, PARSING_ERROR_MSG, PARSING_ERROR_MSG_LENGTH);
		}
		if (ERR == (shell_status = run(commands_ll))) {
			write(STDOUT_FILENO, RUNNING_ERROR_MSG, RUNNING_ERROR_MSG_LENGTH);
		}
	}

	return OK;
}

static void print_prompt(char *path) {
	write(STDOUT_FILENO, path, strlen(path));
	write(STDOUT_FILENO, PROMPT, PROMPT_LENGTH);
}

static int run(s_command *s_commands) {
	s_command *cmd;

	LL_FOREACH(s_commands, cmd) {
		if (!strcmp(cmd->cmd, "exit")) {
			return EXIT;
		}
		if (commons_tsh_is_tarball_involved(&g_state, cmd)) {
			DB_STR("tarball involved");
			/* exec_internal_command(cmd); */
		}
		exec_external_command(cmd);
	}
	return OK;
}

static void exec_external_command(const s_command *cmd) {
	int w_status;

	switch (fork()) {
		case -1:
			{
				perror("fork");
				exit(EXIT_FAILURE);
			}
		break;
		case 0:
			{
				const ssize_t argv_len = cmd->nb_args + 2;
				char *argv[argv_len];

				assert(NULL != (argv[0] = malloc(sizeof(strlen(cmd->cmd)))));
				commons_safe_str_cpy(argv[0], cmd->cmd);

				argv[argv_len-1] = NULL;
				for (int i = 1; i < argv_len - 1; ++i) {
					char *arg = cmd->args[i-1];

					assert(NULL != (argv[i] = malloc(sizeof(strlen(arg)))));
					commons_safe_str_cpy(argv[i], arg);
				}
				execvp(argv[0], argv);
			}
		break;
		default:
			wait(&w_status);
		break;
	}
}

static void init_starting_state() {
	char cwd[PATH_MAX];

	getcwd(cwd, PATH_MAX);
	g_state = *commons_tsh_create_state_from_outside_path(cwd);
}
