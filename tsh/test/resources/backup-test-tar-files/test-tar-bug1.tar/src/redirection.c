#include "inc/redirection.h"

static int saved_stdout = ERR;
static int saved_stdin = ERR;

int redirection_redirect_stdin_to(int fd) {
	saved_stdin = dup(STDOUT_FILENO);

	if (ERR == dup2(fd, STDIN_FILENO)) {
		return ERR;
	}
	return OK;
}

int redirection_redirect_stdout_to(int fd) {
	saved_stdout = dup(STDOUT_FILENO);

	if (ERR == dup2(fd, STDOUT_FILENO)) {
		return ERR;
	}
	return OK;
}

int redirection_reset_stdout() {
	if (0 >= saved_stdout || ERR == dup2(saved_stdout, STDOUT_FILENO)) {
		return ERR;
	}
	return OK;
}

int redirection_reset_stdin() {
	if (0 >= saved_stdin || ERR == dup2(saved_stdin, STDIN_FILENO)) {
		return ERR;
	}
	return OK;
}
