#include "inc/parser.h"

/**
 * Updates cmd->is_tarball_option if option is equal to tarball_option and returns TRUE
 * else, returns FALSE.
 */
static int update_command_is_tarball_option(
	s_command *cmd,
	char *option,
	const int curr_indx,
	const char tarball_option
);

/* Fills new_red with tmp_tsh_state->cwd content. */
static void new_red_init_from_tsh_state(
	s_redirection *new_red,
	s_tsh_state *tmp_tsh_state,
	const int type,
	char *last
);

/* Fills new_red. */
static void new_red_init_from_outside_path(
	s_redirection *new_red,
	char *cwd,
	char *path,
	const redirect_type type
);

/* Removes the file from a path. */
static void split_dirs_and_file(char *path, char **dirs_without_file, char **file);

/* Initilizes a s_command from a command and append it to the s_command linked list. */
static int append_command(s_command **head, char *command);

/* Manages redirections and options of a command. */
static int manages_redirections_and_options(
	s_command *cmd,
	char **args,
	const int nb_args
);

/* Setup and add a new redirection to the linked list of redirection. */
static s_redirection *add_redirection(
	s_redirection **head,
	char *path,
	const redirect_type type
);

static s_redirection *new_red_init_from_tarball_path(
	s_redirection **head,
	s_redirection *new_red,
	char *new_path,
	const redirect_type red_type
);

/* Returns the index of a given args in g_redirect_chars if it is a redirection character. */
static int arg_is_a_redirection_character(const char *args);

/* Prepares the parameter to call add_redirection and call it. */
static int init_right_redirection_according_to_redirection_character(
	s_command **cmd,
	const int redirect_char_index,
	char *path
);

/**
 * Returns TRUE if the line does not begin by a pipe, does not contains consecutive pipes
 * and does not finish with a pipe.
 */
static int line_has_right_format(const char *line);

const char *g_redirect_chars[NB_REDIRCT_SYMB] = {">", ">>", "<", "<<", "2>", "2>>"};

/* Is the path the to current working dir. */
static const char *g_cwd;

s_command *parse(const char *line, const char *cwd) {
	s_command *head = NULL;
	char **commands = NULL;
	int nb_commands = 0;

	g_cwd = cwd;

	if (!line_has_right_format(line)) {
		return NULL;
	}

	if (NULL == (commands = tokenize(line, PIPE_CHR, &nb_commands))) {
		return NULL;
	}

	for (int i = 0; i < nb_commands; i++) {
		if (ERR == append_command(&head, commands[i])) {
			return NULL;
		}
	}

	return head;
}

static int line_has_right_format(const char *line) {
	const ssize_t str_len = strlen(line);

	return 0 != str_len
		&& PIPE_CHR != line[0]
		&& PIPE_CHR != line[str_len-1]
		&& NULL == strstr(line, "||");
}

static int append_command(s_command **head, char *command) {
	int nb_args = 0;
	s_command *cmd = NULL;
	char **args = tokenize(command, ' ', &nb_args);

	if (NULL == (cmd = malloc(sizeof(s_command)))) {
		return ERR;
	}

	commons_safe_str_cpy(cmd->cmd, args[0]);
	cmd->nb_args = nb_args - 1;
	cmd->args = malloc(nb_args * sizeof(char*));

	if (ERR == manages_redirections_and_options(cmd, args, nb_args)) {
		return ERR;
	}

	LL_APPEND(*head, cmd);

	return OK;
}

/**
 * The index of the argument in g_redirect_chars is used to define the redirection type.
 * @see init_right_redirection_according_to_redirection_character).
 */
static int arg_is_a_redirection_character(const char *args) {
	for (int i = 0; i < NB_REDIRCT_SYMB; i++) {
		if (0 == strcmp(args, g_redirect_chars[i])) {
			return i;
		}
	}
	return ERR;
}

/* TODO: Needs to be refatored. */
static int manages_redirections_and_options(s_command *cmd, char **args, const int nb_args) {
	int cmd_args_offset = 0;
	int redirect_char_index;

	for (int j = 0; j < nb_args; j++) {
		/* Look to find redirections or option char. */
		if (MAX_REDIRECT_SYMB_SIZE >= strlen(args[j])) {
			/* Manages redirections. */
			if (ERR != (redirect_char_index = arg_is_a_redirection_character(args[j]))) {
				/* If the redirection character is the last one return an error. */
				if (j >= nb_args - 1) {
					return ERR;
				}
				if (NULL == cmd->redirections) {
					cmd->redirections = malloc(sizeof(s_command_redirections));
				}
				if (ERR == init_right_redirection_according_to_redirection_character(
							&cmd, redirect_char_index, args[j+1])
				) {
					return ERR;
				}

				/* Command is like '> path cmd' */
				if (0 == j) {
					if (3 > nb_args) {
						return ERR;
					}
					else {
						commons_safe_str_cpy(cmd->cmd, args[j+2]);
						for (int i = 0; i < 3; i++) {
							args[i] = NULL;
						}
						j += 3;
						cmd->nb_args -= 2;
					}
				}
				else {
					j += 1;
					cmd->nb_args -= 2;
					continue;
				}
			}
		}

		/* Manages options. */
		if (j < nb_args && '-' == args[j][0]) {
			cmd->is_with_option = TRUE;

			if (0 == strcmp(cmd->cmd, "ls")) {
				if (update_command_is_tarball_option(cmd, args[j], j, 'l')) {
					args[j] = NULL;
				}
			}
			else if (0 == strcmp(cmd->cmd, "cp")) {
				if (update_command_is_tarball_option(cmd, args[j], j, 'r')) {
					args[j] = NULL;
				}
			}
		}

		/* The current arg is not equal to NULL means that we add it to the
		 * array of arguments of the current s_command.
		 */
		if (NULL != args[j] && 0 != j) {
			cmd->args[cmd_args_offset] = (char*)malloc(CMD_MAX_SIZE * sizeof(char));
			commons_safe_str_cpy(cmd->args[cmd_args_offset], args[j]);
			cmd_args_offset++;
		}
	}
	return OK;
}

static redirect_type get_redirection_type(const int redirect_char_index) {
	if (redirect_char_index > NB_REDIRCT_SYMB) {
		return ERR;
	}
	/* Given an index i, if i is even, the redirection flag is O_TRUNC
	 * @see g_redirect_chars.
	 */
	if (0 == redirect_char_index % 2)  {
		return REDIRECT_TRUNC;
	}

	return REDIRECT_APPEND;
}

static int init_right_redirection_according_to_redirection_character(
	s_command **cmd,
	const int redirect_char_index,
	char *path)
{
	redirect_type redirection_type;

	if (ERR == (redirection_type = get_redirection_type(redirect_char_index))) {
		return ERR;
	}

	switch (g_redirect_chars[redirect_char_index][0]) {
		case '>':
			if (NULL == (*cmd)->redirections->out) {
				(*cmd)->redirections->out = add_redirection(&((*cmd)->redirections->out), path, redirection_type);
				if (NULL == (*cmd)->redirections->out) {
					return ERR;
				}
			}
			else {
				return ERR;
			}
		break;
		case '<':
			if (NULL == (*cmd)->redirections->in) {
				(*cmd)->redirections->in = add_redirection(&((*cmd)->redirections->in), path, redirection_type);
				if (NULL == (*cmd)->redirections->in) {
					return ERR;
				}
			}
			else {
				return ERR;
			}
		break;
		case '2':
			if (NULL == (*cmd)->redirections->err) {
				(*cmd)->redirections->err = add_redirection(&((*cmd)->redirections->err), path, redirection_type);
				if (NULL == (*cmd)->redirections->err) {
					return ERR;
				}
			}
			else {
				return ERR;
			}
		break;
	}

	return OK;
}

static int update_command_is_tarball_option(
	s_command *cmd,
	char *option,
	const int curr_indx,
	const char tarball_option)
{
	if (tarball_option == option[1] && 2 == strlen(option)) {
		cmd->is_tarball_option = TRUE;
		cmd->nb_args--;

		return TRUE;
	}
	return FALSE;
}

char **tokenize(const char *line, const char delimiter, int *nb_args) {
	char **tokens;
	char *tok = strtok(strdup(line), &delimiter);
	ssize_t curr_tokens_capacity = DEFAULT_NB_COMMANDS_ARGS;
	int curr_tokens_size = 0;

	assert(NULL != (tokens = malloc(curr_tokens_capacity * sizeof(char*))));

	while (NULL != tok) {
		if (is_str_contain_only_spaces(tok)) {
			return NULL;
		}
		if (curr_tokens_size >= curr_tokens_capacity) {
			curr_tokens_capacity += DEFAULT_NB_COMMANDS_ARGS;
			assert(NULL != (tokens = realloc(tokens, curr_tokens_capacity * sizeof(char*))));
		}
		tokens[curr_tokens_size] = tok;
		curr_tokens_size++;
		tok = strtok(NULL, &delimiter);
	}

	*nb_args = curr_tokens_size;

	free(tok);

	return tokens;
}

static s_redirection *add_redirection(s_redirection **head, char *path, const redirect_type red_type) {
	char *absolute_path = malloc(PATH_MAX);
	s_redirection *new_red = malloc(sizeof(s_redirection));
	int tmp_fd;

	assert(NULL != absolute_path);
	assert(NULL != new_red);

	if (PATH_DELIMITER_CHR != path[0]) {
		commons_safe_str_cpy(absolute_path, g_cwd);
		strcat(absolute_path, path);
	}
	else {
		commons_safe_str_cpy(absolute_path, path);
	}

	if (0 < (tmp_fd = open(absolute_path, O_RDONLY | O_CREAT))) {
		/* path is ok and does not involve tarball */
		new_red_init_from_outside_path(new_red, absolute_path, path, red_type);
		close(tmp_fd);
		return new_red;
	}
	/* path involve tarball */
	new_red = new_red_init_from_tarball_path(head, new_red, absolute_path, red_type);
	return new_red;
}

/**
 * Needs to tokenize and concatenate up to second to last, in order to
 * remove the last element of the path (the destination file)
 * in order to use commons_tsh_update_state_from_path.
 */
static s_redirection *new_red_init_from_tarball_path(
	s_redirection **head,
	s_redirection *new_red,
	char *new_path,
	const redirect_type red_type)
{
	s_tsh_state *tmp_tsh_state;
	char *file = malloc(PATH_MAX);
	char *path_without_last = malloc(PATH_MAX);

	assert(NULL != file && NULL != path_without_last);

	split_dirs_and_file(new_path, &path_without_last, &file);

	/* init a temp struct tsh_state to get its tsh_path */
	tmp_tsh_state = commons_tsh_create_state_from_outside_path(new_path);

	if (0 < commons_tsh_update_state_from_path(tmp_tsh_state, path_without_last)) {
		new_red_init_from_tsh_state(new_red, tmp_tsh_state, red_type, file);
		return new_red;
	}

	return NULL;
}

static void split_dirs_and_file(char *path, char **dirs_without_file, char **file) {
	int nb_tokens = 0;
	char **tokens = tokenize(path, PATH_DELIMITER_CHR, &nb_tokens);

	commons_safe_str_cpy(*dirs_without_file, PATH_DELIMITER_STR);
	for (int i = 0; i < nb_tokens-1; i++) {
		strcat(*dirs_without_file, tokens[i]);
		strcat(*dirs_without_file, PATH_DELIMITER_STR);
	}
	commons_safe_str_cpy(*file, tokens[nb_tokens-1]);
}

static void new_red_init_from_outside_path(
	s_redirection *new_red,
	char *cwd,
	char *path,
	const redirect_type type)
{
	assert(NULL != (new_red->path = malloc(sizeof(s_tsh_path))));
	commons_safe_str_cpy(new_red->path->inside_path, "");
	commons_safe_str_cpy(new_red->path->outside_path, cwd);
	new_red->type = type;
}

static void new_red_init_from_tsh_state(
	s_redirection *new_red,
	s_tsh_state *tmp_tsh_state,
	const int type, char *last)
{
	new_red->path = malloc(sizeof(s_tsh_path));
	assert(NULL != new_red->path);

	new_red->path = tmp_tsh_state->cwd;
	strcat(new_red->path->inside_path, last);
	new_red->type = type;
}
