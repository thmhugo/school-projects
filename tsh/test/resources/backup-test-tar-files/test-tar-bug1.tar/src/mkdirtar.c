#include "inc/mkdirtar.h"

int mkdirtar(const int tar_fd, const char *path_from_tar_root) {
    s_posix_header pheader;

    if (TRUE == commons_tar_find_file_from(tar_fd, path_from_tar_root, &pheader)) {
        return ERR;
    }

    return commons_tar_append_dir(tar_fd, path_from_tar_root);
}