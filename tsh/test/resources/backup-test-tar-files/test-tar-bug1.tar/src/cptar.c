#include "inc/cptar.h"

/* Writes the content from a tarbal to a tarball
 * (can be the same). */
static int cptar_from_tarball_to_tarball(
	const s_tsh_path source_path,
	const s_tsh_path destination_path
);

/* Manages the file descriptor before calling cptar_to_an_other_file. */
static int cptar_outside(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	s_posix_header pheader
);

/* Writes the content to another file. */
static int cptar_to_an_other_file(
	const int src_fd,
	const int dest_fd,
	s_posix_header pheader
);

/* Appends an extern file to the tarball using commons_tar_append_file.
 * @see commons_tar.h
 */
static int append_extern_file_to(
	const char *extern_file_path,
	const int tarball_fd,
	const char *new_file_name
);

/* Manages cp cases without option. */
static int cptar_without_option(
	const s_tsh_path source_path,
	const s_tsh_path destination_path
);

/* Manages cp cases with option. */
static int cptar_with_option(
	const s_tsh_path source_path,
	const s_tsh_path destination_path
);

/* Creates the new desination file name. */
static char* create_new_destination_name(
	char *new_file_name_root,
	const char *current_file_inside_path,
	char *header_name
);

/* Iterates over a tarball to read files and copy if the path corresponds. */
static int cptar_children(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	s_posix_header pheader,
	const int to_outside
);

/* Factorisation of the call to functions that create dir or file into a tarball. */
static int cptar_file_or_dir_into_tarball(
	const s_tsh_path source_path,
	const s_tsh_path original_destination_path,
	char *new_destination_file_name,
	s_posix_header pheader
);

/* Factorisation of the call to functions that create dir or file outside a tarball. */
static int cptar_file_or_dir_outside(
	const s_tsh_path source_path,
	const s_tsh_path original_destination_path,
	char *new_destination_file_name,
	s_posix_header pheader
);

/* Recursively explores a directory to copy it completely into a tarball. */
static int read_dir_and_tar_append(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	s_posix_header pheader
);

/* Creates the file intermediate names, used when exploring a directory. */
static void create_intermediate_name(char *new_path, const char *root, char *end);

/* Get the intermediates source and destination file names
 * makes the copy when running a tarball.
 */
static int cptar_internal_tarball_content(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	char *new_file_name_root,
	s_posix_header pheader,
	const int to_outside
);

/* Verifies if the source path is a dir or not (in a tarball or outside). */
static int file_is_a_dir(const s_tsh_path source_path, s_posix_header pheader);

int cptar(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	const int with_option
) {
	if (with_option) {
		return cptar_with_option(source_path, destination_path);
	}

	return cptar_without_option(source_path, destination_path);
}

static int cptar_without_option(
	const s_tsh_path source_path,
	const s_tsh_path destination_path
) {
	s_posix_header pheader;

	if ((commons_tar_is_valid(source_path.tar_fd)
		&& (!commons_tar_find_file_from(source_path.tar_fd, source_path.inside_path, &pheader)))
		|| commons_tar_is_dir(pheader))
	{
		return ERR;
	}

	/* Case : from a tarball to a tarball. */
	if (commons_tar_is_valid(source_path.tar_fd)
		&& commons_tar_is_valid(destination_path.tar_fd))
	{
		return cptar_from_tarball_to_tarball(
			source_path,
			destination_path
		);
	}

	/* Case : from a tarball to a file outside. */
	if (commons_tar_is_valid(source_path.tar_fd)
		&& !commons_tar_is_valid(destination_path.tar_fd))
	{
		return cptar_outside(source_path, destination_path, pheader);
	}

	/* Case : from a file outside to a tarball. */
	return append_extern_file_to(
		source_path.outside_path,
		destination_path.tar_fd,
		destination_path.inside_path
	);
}

static int cptar_with_option(
	const s_tsh_path source_path,
	const s_tsh_path destination_path
) {
	s_posix_header pheader;

	if (file_is_a_dir(source_path, pheader)) {
		return cptar_without_option(source_path, destination_path);
	}

        /* Case : from a tarball to a tarball. */
	if (commons_tar_is_valid(source_path.tar_fd)
		&& commons_tar_is_valid(destination_path.tar_fd))
	{
		return cptar_children(source_path, destination_path, pheader, FALSE);
	}

	/* Case : from a tarball to a file outside. */
	if (commons_tar_is_valid(source_path.tar_fd)
		&& !commons_tar_is_valid(destination_path.tar_fd))
	{
		return cptar_children(source_path, destination_path, pheader, TRUE);
	}

	/**
	 * Case : from outside into a tarball
	 * Need to append the source directory before read_dir_and_tar_append,
	 * because read_dir_and_tar_append goes directly into the directory.
	 */
	if (ERR == commons_tar_append_file(
		destination_path.tar_fd, source_path, destination_path.inside_path))
	{
		return ERR;
	}
	return read_dir_and_tar_append(source_path, destination_path, pheader);
}

static int cptar_children(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	s_posix_header pheader,
	const int to_outside
) {
	char new_file_name_root[TAR_NAME_SIZE];

	if (to_outside) {
		commons_safe_str_cpy(new_file_name_root, destination_path.outside_path);
	}
	else {
		commons_safe_str_cpy(new_file_name_root, destination_path.inside_path);
	}


	lseek(source_path.tar_fd, 0, SEEK_SET);

	while (0 < read(source_path.tar_fd, &pheader, TAR_BLOCKSIZE) &&  NONECHAR != pheader.name[0]) {
		/* If the read header has source_path.inside_path as ancestor : it is copied. */
		if (
			commons_tar_is_same_ancestor(
				source_path.tar_fd,
				source_path.inside_path,
				pheader.name))
		{
			const off_t saved_offset = lseek(source_path.tar_fd, 0, SEEK_CUR);

			if (ERR == cptar_internal_tarball_content(
				source_path,
				destination_path,
				new_file_name_root,
				pheader,
				to_outside
			)) {
				return ERR;
			}

			lseek(source_path.tar_fd, saved_offset, SEEK_SET);
		}
		
		commons_tar_lseek_size_of_file(source_path.tar_fd, &pheader);
	}
	return OK;
}

static int cptar_internal_tarball_content(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	char *new_file_name_root,
	s_posix_header pheader,
	const int to_outside
) {
	char *new_destination_file_name;
	s_tsh_path *new_source_path;

	/* Creation of the new file destination name and associated tsh_path. */
	new_destination_file_name =
		create_new_destination_name(
			new_file_name_root,
			source_path.inside_path,
			pheader.name
		);

	/**
 	*	The given s_tsh_path corresponds to the source directory.
	*	As we iterate of all files, we need to get the tsh_path of
	*	the copied file or directory.
	*/
	new_source_path =
		commons_tsh_create_s_tsh_path(
			source_path.outside_path,
			pheader.name,
			source_path.tar_fd);

	if (to_outside) {
		if (ERR == cptar_file_or_dir_outside(
			*new_source_path,
			destination_path,
			new_destination_file_name,
			pheader
		)) {
			return ERR;
		}
	} 
	else {
		if (ERR == cptar_file_or_dir_into_tarball(
			*new_source_path,
			destination_path,
			new_destination_file_name,
			pheader
		)) {
			return ERR;
		}
	}
	free(new_source_path);
	return OK;
}

static int read_dir_and_tar_append(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	s_posix_header pheader
) {
	char new_source_file_name[PATH_MAX];
	char new_destination_file_name[TAR_NAME_SIZE];
	s_tsh_path *new_source_path;
	struct dirent *entry;
	DIR *dirp;

	if (!commons_is_dir(source_path)) {
		/* The source is not a directory. */
		return append_extern_file_to(
			source_path.outside_path,
			destination_path.tar_fd,
			destination_path.inside_path
		);
	}

	if (NULL == (dirp=opendir(source_path.outside_path))) {
		return ERR;
	}

	while ((entry = readdir(dirp))) {
		if (0 == strcmp(".", entry->d_name) || 0 == strcmp("..", entry->d_name)) {
			continue;
		}

		if (DT_DIR == entry->d_type) {
			strcat(entry->d_name, "/");
		}

		create_intermediate_name(new_destination_file_name,  destination_path.inside_path, entry->d_name);
		create_intermediate_name(new_source_file_name,  source_path.outside_path, entry->d_name);

		new_source_path =
			commons_tsh_create_s_tsh_path(
				new_source_file_name,
				source_path.inside_path,
				source_path.tar_fd
		);

		if (ERR == cptar_file_or_dir_into_tarball(
			*new_source_path,
			destination_path,
			new_destination_file_name,
			pheader
		)) {
			return ERR;
		}

		/* Recursive call inside a directory. */
		if (DT_DIR == entry->d_type) {
			if (ERR == read_dir_and_tar_append(
						*new_source_path,
						*commons_tsh_create_s_tsh_path(
							destination_path.outside_path,
							new_destination_file_name,
							destination_path.tar_fd),
						pheader))
			{
				return ERR;
			}
		}
	}

	closedir(dirp);
	return OK;
}

static int cptar_file_or_dir_outside(
	const s_tsh_path source_path,
	const s_tsh_path original_destination_path,
	char *new_destination_file_name,
	s_posix_header pheader
) {
	s_tsh_path *new_destination_path;

	new_destination_path =
		commons_tsh_create_s_tsh_path(
			new_destination_file_name,
			"",
			FD_NOTDEF
		);

	if (commons_tar_is_dir(pheader)) {
		mkdir(new_destination_file_name,  S_IRWXU);
	}
	else {
		if (ERR == cptar_outside(source_path, *new_destination_path, pheader)) {
			return ERR;
		}
	}
	free(new_destination_path);

	return OK;
}

static int cptar_file_or_dir_into_tarball(
	const s_tsh_path source_path,
	const s_tsh_path original_destination_path,
	char *new_destination_file_name,
	s_posix_header pheader
) {
	s_tsh_path *new_destination_path;

	new_destination_path =
		commons_tsh_create_s_tsh_path(
			original_destination_path.outside_path,
			new_destination_file_name,
			original_destination_path.tar_fd
	);

	if (commons_tar_is_dir(pheader)) {
		mkdirtar(new_destination_path->tar_fd, new_destination_file_name);
	}
	else {
		if (ERR == cptar_from_tarball_to_tarball(source_path, *new_destination_path)) {
			return ERR;
		}
	}

	free(new_destination_path);

	return OK;
}

static int cptar_outside(
	const s_tsh_path source_path,
	const s_tsh_path destination_path,
	s_posix_header pheader
) {
	int destination_fd;
	int cptar_return;

	if (ERR == (destination_fd = open(destination_path.outside_path, O_RDWR | O_CREAT, S_IRWXU))) {
		return ERR;
	}

	cptar_return =
		cptar_to_an_other_file(
			source_path.tar_fd,
			destination_fd,
			pheader
		);

	close(destination_fd);
	return cptar_return;
}

static int append_extern_file_to(
	const char *extern_file_path,
	const int tarball_fd,
	const char *new_file_name
) {
	s_tsh_path path;

	commons_safe_str_cpy(path.outside_path, extern_file_path);
	path.tar_fd = FD_NOTDEF;

	return commons_tar_append_file(tarball_fd, path, new_file_name);
}

static int cptar_from_tarball_to_tarball(
	const s_tsh_path source_path,
	const s_tsh_path destination_path
) {
	int tmp_destination_tar_fd;
	int append_return_value;

	if (source_path.tar_fd == destination_path.tar_fd) {
		if (ERR == (
			tmp_destination_tar_fd = open(destination_path.outside_path, O_RDWR)
			)) {
			return ERR;
		}
	}
	else {
		tmp_destination_tar_fd = destination_path.tar_fd;
	}

	commons_tar_lseek_to_the_end(tmp_destination_tar_fd);

	append_return_value =
		commons_tar_append_file(
			tmp_destination_tar_fd,
			source_path,
			destination_path.inside_path
	);

	if (source_path.tar_fd == destination_path.tar_fd) {
		close(tmp_destination_tar_fd);
	}

	return append_return_value;
}

static int cptar_to_an_other_file(
	const int src_fd,
	const int dest_fd,
	s_posix_header pheader
) {
	char buffer[TAR_BLOCKSIZE];
	ssize_t read_size;
	ssize_t write_size;

	int nb_source_blocks = commons_tar_get_content_nb_blocks(pheader);

	memset(buffer, 0, TAR_BLOCKSIZE);
	while (0 < nb_source_blocks--) {
		read_size = read(src_fd, buffer, TAR_BLOCKSIZE);
		write_size = write(dest_fd, buffer, TAR_BLOCKSIZE);

		if (read_size != write_size) {
			return ERR;
		}
	}

	return OK;
}

static char* create_new_destination_name(
	char *new_file_name_root,
	const char *current_file_inside_path,
	char *header_name
) {
	char *new_destination_file_name;
	char *new_file_name_end =
		commons_tar_format_name_according_min_depth(
			header_name,
			commons_tar_get_depth(
				current_file_inside_path
			)
		);

	new_destination_file_name = malloc(TAR_NAME_SIZE);
	create_intermediate_name(new_destination_file_name, new_file_name_root, new_file_name_end);
	return new_destination_file_name;
}

static void create_intermediate_name(char *new_path, const char *root, char *end) {
	commons_safe_str_cpy(new_path, root);
	if (PATH_DELIMITER_CHR != new_path[strlen(new_path)-1]) {
		strcat(new_path, PATH_DELIMITER_STR);
	}
	strcat(new_path, end);
}

static int file_is_a_dir(const s_tsh_path source_path, s_posix_header pheader) {
  const int fd = source_path.tar_fd;
  const char *path = source_path.inside_path;

  return (commons_tar_is_valid(fd) &&
          !commons_tar_find_dir_from(fd, path, &pheader)) ||
         (!commons_tar_is_valid(fd) && !commons_is_dir(source_path));
}