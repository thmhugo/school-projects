#include "inc/cd.h"

int cd(s_tsh_state *tsh_state, char *path) {
 	switch (commons_tsh_update_state_from_path(tsh_state, path)) {
		case ERR:
			return ERR;
		break;
		case FD_NOTDEF:
			return chdir(tsh_state->cwd->outside_path);
		break;
		default:
		{
			char tmp_buffer[PATH_MAX];

			strcpy(tmp_buffer, tsh_state->cwd->outside_path);

			return chdir(dirname(tmp_buffer));
		}
	}
}
