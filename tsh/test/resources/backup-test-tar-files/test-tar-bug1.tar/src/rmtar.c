#include "inc/rmtar.h"

/** Initializes the destination offset corresponding to the file to be erased and
        the source offset associated to the next file to be copied. */
static void init_offsets(
        const int tar_fd, 
        ssize_t *src_offset, 
        ssize_t *dest_offset, 
        const s_posix_header *pheader
);

/** Removes `path_from_tar_root` children. */
static int rmtar_children(const int tar_fd, const char *path_from_tar_root);

int rmtar(const int tar_fd, const int with_option, const char *path_from_tar_root) {
    s_posix_header pheader;
    ssize_t dest_offset;
    ssize_t src_offset;

    if (!commons_tar_find_file_from(tar_fd, path_from_tar_root, &pheader)) {
        return ERR;
    }

    if (with_option) {
        lseek(tar_fd, 0, SEEK_SET);
        return rmtar_children(tar_fd, path_from_tar_root);
    }

	/* Should return an error when the '-r' option is not specified but the wanted file is a directory. */
    if (commons_tar_is_dir(pheader)) {
        return ERR;
    }

    init_offsets(tar_fd, &src_offset, &dest_offset, &pheader);

    return commons_tar_blockmove(tar_fd, dest_offset, src_offset);
}

static void init_offsets(
        const int tar_fd, 
        ssize_t *src_offset, 
        ssize_t *dest_offset, 
        const s_posix_header *pheader
) {
    *dest_offset = lseek(tar_fd, -TAR_BLOCKSIZE, SEEK_CUR);
    lseek(tar_fd, TAR_BLOCKSIZE, SEEK_CUR);
    commons_tar_lseek_size_of_file(tar_fd, pheader);
    *src_offset = lseek(tar_fd, 0, SEEK_CUR);
}

static int rmtar_children(const int tar_fd, const char *path_from_tar_root) {
    s_posix_header pheader;
    ssize_t dest_offset;
    ssize_t src_offset;

    while (0 < read(tar_fd, &pheader, TAR_BLOCKSIZE) && NONECHAR != pheader.name[0]) {
        /* Checks all the headers and if the name contains path_from_tar_root, removes the file.*/
        if (commons_tar_is_same_ancestor(tar_fd, path_from_tar_root, pheader.name)) {
            init_offsets(tar_fd, &src_offset, &dest_offset, &pheader);

            if (ERR == commons_tar_blockmove(tar_fd, dest_offset, src_offset)) {
                return ERR;
            }

            /* Reposition the file offset to the correct location after deleting a file. */
            lseek(tar_fd, dest_offset, SEEK_SET);
        }
        else {
            commons_tar_lseek_size_of_file(tar_fd, &pheader);
        }
    }

    return OK;
}