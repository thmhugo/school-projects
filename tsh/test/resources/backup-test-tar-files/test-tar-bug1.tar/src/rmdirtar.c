#include "inc/rmdirtar.h"

int rmdirtar(const int tar_fd, const char *path_from_tar_root) {
    s_posix_header pheader;
    ssize_t dest_offset;
    ssize_t src_offset;

    if (commons_tar_find_file_from(tar_fd, path_from_tar_root, &pheader) &&
        TAR_DIR_F == pheader.typeflag &&
        commons_tar_is_dir_empty(tar_fd, path_from_tar_root))
	{
        dest_offset = lseek(tar_fd, -TAR_BLOCKSIZE, SEEK_CUR);
        lseek(tar_fd, TAR_BLOCKSIZE, SEEK_CUR);
        src_offset = lseek(tar_fd, 0, SEEK_CUR);

        return commons_tar_blockmove(tar_fd, dest_offset, src_offset);
    }

    return ERR;
}
