#include "inc/mvtar.h"

int mvtar(const s_tsh_path source_path, const s_tsh_path destination_path) {
	if (ERR == cptar(source_path, destination_path, TRUE)) {	
		return ERR;
	}

	if (commons_tar_is_valid(source_path.tar_fd)) {
		return rmtar(source_path.tar_fd, TRUE, source_path.inside_path);
	}

	return commons_remove_file(source_path.outside_path);
}