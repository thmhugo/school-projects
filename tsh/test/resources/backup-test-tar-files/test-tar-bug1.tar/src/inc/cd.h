#ifndef CD_H
#define CD_H

#include "commons_tar.h"
#include "commons_tsh.h"
#include "tsh.h"

/**
 * Updates the current tsh_state and the cwd according to the given path.
 *
 * @param tsh_state is the current tsh state to modify.
 * @param path is the path to the wanted dir.
 *
 * @return ERR if an error occured (tsh_state is not modified), else, OK.
 */
int cd(s_tsh_state *tsh_state, char *path);

#endif
