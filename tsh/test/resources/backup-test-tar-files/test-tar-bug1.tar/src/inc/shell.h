#ifndef SHELL_H
#define SHELL_H

#include <sys/wait.h>
#include <unistd.h>

#include "commons.h"
#include "commons_tsh.h"
#include "parser.h"
#include "tsh.h"

#define WELCOME_MSG_LENGTH 46
#define WELCOME_MSG "--- Running \033[34mtsh\033[0m ---\n"

#define PROMPT_LENGTH  	3
#define PROMPT 			" > "

#define PARSING_ERROR_MSG_LENGTH  34
#define PARSING_ERROR_MSG	 "An error occured while parsing...\n"

#define RUNNING_ERROR_MSG_LENGTH  34
#define RUNNING_ERROR_MSG	 "An error occured while running...\n"

#define EXIT  1

#endif
