#ifndef PARSER_H
#define PARSER_H

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "commons.h"
#include "commons_tar.h"
#include "commons_tsh.h"
#include "redirection.h"
#include "tsh.h"
#include "utlist.h"

#define DEFAULT_NB_COMMANDS_ARGS 10

/**
 * Parses a tsh input (string representations of commands).
 *
 * @note With hindsight, implementing the parser with a library like Argp would have been
 * less laborious, more understandable and stable. However, we are running out
 * of time and we need to keep our parser implemented by hand.
 *
 * @param line is string representations of commands.
 * @param cwd is the absolute path to the current working dir.
 *
 * @return a linked list of s_command.
 */
s_command *parse(const char *line, const char *cwd);

/**
 * Tokenizes the line according a delimiter.
 *
 * @param str is the string to tokenize .
 * @param delimiter is the delimiter used to tokenize the line.
 * @param nb_args is a pointer to an int that store the number of tokens in the retured array.
 *
 * @returns an array of tokens.
 */
char **tokenize(const char *str, const char delimiter, int *nb_args);

#endif
