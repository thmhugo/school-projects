#ifndef CATTAR_H
#define CATTAR_H

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "commons_tar.h"
#include "tar.h"

/**
 * Writes in stdout the contents of all the files given of a supposed valid tarball.
 *
 * @param tar_fd is the file descriptor corresponding to the tarball.
 * @param path_from_tar_root is the searched file in the tarball.
 *
 * @return ERR if an error occured else OK.
 */
int cattar(const int tar_fd, const char *path_from_tar_root);

#endif
