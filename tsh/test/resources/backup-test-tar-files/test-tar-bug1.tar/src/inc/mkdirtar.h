#ifndef MKDIRTAR_H
#define MKDIRTAR_H

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#include "commons_tar.h"
#include "tar.h"


/**
 * Creates a new folder in the tarball.
 *
 * @param tar_fd is the file descriptor corresponding to the tarball.
 * @param path_from_tar_root is the file to be created in the tarball.
 *
 * @return ERR (-1) in these cases:
 *                      a file with the same name is present
 *                      or writing errors.
 *  else OK (0).
 */
int mkdirtar(const int tar_fd, const char *path_from_tar_root);

#endif
