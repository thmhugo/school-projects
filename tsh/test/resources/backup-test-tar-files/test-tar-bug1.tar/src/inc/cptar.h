#ifndef CPTAR_H
#define CPTAR_H

#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <dirent.h>

#include "tar.h"
#include "commons_tar.h"
#include "commons_tsh.h"
#include "mkdirtar.h"

/**
 * cp implementation for the tarballs.
 *
 * @param source_path is the s_tsh_path to the source file to copy.
 * @param destination_path is the s_tsh_path to the destination file
 * @param with_option specify if the option "-r" is needed.
 *
 * @return ERR if the source file does not exist or if a writing/reading error occured, else OK.
 */
int cptar(
    const s_tsh_path source_path,
    const s_tsh_path destination_path,
    const int with_option
);

#endif
